package Pack1;

public class Protected {
	public void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 


}

package Pack2;

public class Public {
	public void display() 
    { 
        System.out.println("This is Public Access Specifiers"); 
    } 


}

package innerclass;

public class innerClassAssited3 {

}
